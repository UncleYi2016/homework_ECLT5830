
<?php
  require_once('lib/init.php');
  include('view/index.php');
  // No special application logic for home page (at least for assignment #3)
  // except to include lib/init.php to initialize some constant
?>

 