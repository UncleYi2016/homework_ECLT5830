<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $view_title; ?></title>

    <link rel="stylesheet" href="<?php echo APP_ROOT_FOLDER;?>/css/asgn3.css">

  </head>
  <body><div>

    <ul>
      <li><a href="index.php">ECLT5830 Assignment #3</a></li>
      <li><a href="list_items.php">List Items</a></li>
      <li><a href="item.php?id=1">Show Item with item_id=1</a></li>
    </ul>
