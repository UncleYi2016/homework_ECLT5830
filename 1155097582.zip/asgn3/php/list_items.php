<?php
  require_once('lib/items.php');

  // Controller for "listing multiple items"

  // Place holder with test data
  $items = [getItem(1), getItem(2), getItem(3)];


  // TODO: Retrieve all items from DB  and store them in $items.
?>


<?php include('view/list_items.php'); ?>




